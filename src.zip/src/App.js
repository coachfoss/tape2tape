// src/App.js
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import VideoUpload from "./VideoUpload";
import Dashboard from "./Dashboard";
import ReviewViewer from "./ReviewViewer";
import CoachEditor from "./CoachEditor";
import Auth from "./Auth";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "./firebase";

export default function App() {
  const [user, loading] = useAuthState(auth);

  if (loading) return <p style={{ padding: 20 }}>Loading...</p>;

  return (
    <Routes>
      {!user ? (
        <>
          {/* Logged OUT */}
          <Route path="/login" element={<Auth />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </>
      ) : (
        <>
          {/* Logged IN */}
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/upload" element={<VideoUpload />} />
          <Route path="/review" element={<ReviewViewer />} />
          <Route path="/editor" element={<CoachEditor />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </>
      )}
    </Routes>
  );
}
