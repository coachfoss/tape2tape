import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { storage, db } from "./firebase";
import { ref, getDownloadURL } from "firebase/storage";
import { doc, getDoc } from "firebase/firestore";

export default function ReviewViewer() {
  const location = useLocation();
  const { videoId } = location.state || {};

  const [videoUrl, setVideoUrl] = useState("");
  const [videoName, setVideoName] = useState("");
  const [annotations, setAnnotations] = useState([]);
  const [voiceUrl, setVoiceUrl] = useState(null);
  const [analysisUrl, setAnalysisUrl] = useState(null);
  const [loading, setLoading] = useState(true);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  // Load video doc
  useEffect(() => {
    const fetchVideo = async () => {
      if (!videoId) {
        setLoading(false);
        return;
      }
      try {
        const snap = await getDoc(doc(db, "videos", videoId));
        if (snap.exists()) {
          const d = snap.data();
          setVideoUrl(d.url);
          setVideoName(d.name || "Untitled");
        }
      } catch (err) {
        console.error("❌ Could not fetch video doc", err);
      } finally {
        setLoading(false);
      }
    };
    fetchVideo();
  }, [videoId]);

  // Load review overlays + voice + analysis
  useEffect(() => {
    if (!videoName) return;
    const base = videoName.replace(/\.mp4$/i, "");
    const loadReview = async () => {
      // Annotations JSON
      try {
        const jsonRef = ref(storage, `reviews/${base}-review.json`);
        const jsonUrl = await getDownloadURL(jsonRef);
        const res = await fetch(jsonUrl);
        setAnnotations(await res.json());
      } catch {
        setAnnotations([]);
      }
      // Voice note
      try {
        const voiceRef = ref(storage, `reviews/${base}-voice.webm`);
        setVoiceUrl(await getDownloadURL(voiceRef));
      } catch {
        setVoiceUrl(null);
      }
      // Analysis video (preferred)
      try {
        const analysisRef = ref(storage, `reviews/${base}-analysis.webm`);
        setAnalysisUrl(await getDownloadURL(analysisRef));
      } catch {
        setAnalysisUrl(null);
      }
    };
    loadReview();
  }, [videoName]);

  // Render overlay (persistent, only if no analysis video)
  useEffect(() => {
    if (analysisUrl) return; // play analysis instead
    const c = canvasRef.current;
    const ctx = c?.getContext("2d");
    if (!c || !ctx || annotations.length === 0) return;
    let rafId;
    const render = () => {
      const v = videoRef.current;
      if (!v) return;
      c.width = v.videoWidth || 640;
      c.height = v.videoHeight || 360;
      ctx.clearRect(0, 0, c.width, c.height);

      for (const s of annotations) {
        if (!s) continue;
        ctx.strokeStyle = s.color || "#ff0000";
        ctx.lineWidth = s.lineWidth || 2;
        if (s.type === "line") {
          ctx.beginPath();
          ctx.moveTo(s.x1, s.y1);
          ctx.lineTo(s.x2, s.y2);
          ctx.stroke();
        }
        if (s.type === "rect") ctx.strokeRect(s.x, s.y, s.w, s.h);
        if (s.type === "circle") {
          ctx.beginPath();
          ctx.arc(s.cx, s.cy, s.r, 0, Math.PI * 2);
          ctx.stroke();
        }
        if (s.type === "freehand" && s.points?.length) {
          ctx.beginPath();
          ctx.moveTo(s.points[0].x, s.points[0].y);
          for (const pt of s.points) ctx.lineTo(pt.x, pt.y);
          ctx.stroke();
        }
      }
      rafId = requestAnimationFrame(render);
    };
    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, [annotations, analysisUrl]);

  if (!videoId) return <p style={{ padding: 20 }}>⚠️ No video selected.</p>;
  if (loading) return <p style={{ padding: 20 }}>Loading review…</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Review Viewer</h2>
      <p><em>{videoName}</em></p>

      {analysisUrl ? (
        // Preferred: single analysis video (composited)
        <video src={analysisUrl} controls style={{ width: 640, height: 360, background: "#000" }} />
      ) : videoUrl ? (
        // Fallback: original video + persistent overlay + optional voice note
        <>
          <div style={{ position: "relative", width: 640, height: 360 }}>
            <video
              ref={videoRef}
              src={videoUrl}
              controls
              style={{ display: "block", width: 640, height: 360, background: "#000" }}
            />
            <canvas
              ref={canvasRef}
              width="640"
              height="360"
              style={{ position: "absolute", top: 0, left: 0 }}
            />
          </div>
          {voiceUrl && (
            <div style={{ marginTop: 12 }}>
              <audio src={voiceUrl} controls />
            </div>
          )}
        </>
      ) : (
        <p>Video not found.</p>
      )}
    </div>
  );
}
