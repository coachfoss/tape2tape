import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { storage, db } from "./firebase";
import { ref, uploadBytes } from "firebase/storage";
import { doc, getDoc, serverTimestamp, updateDoc } from "firebase/firestore";

const TOOLS = ["line", "rect", "circle", "freehand", "eraser"];
const DEFAULT_COLOR = "#ff0000"; // locked to red for now

export default function CoachEditor() {
  const location = useLocation();
  const navigate = useNavigate();
  const { videoId } = location.state || {};

  const [videoUrl, setVideoUrl] = useState("");
  const [videoName, setVideoName] = useState("");
  const [loading, setLoading] = useState(true);

  const stageRef = useRef(null);            // responsive stage wrapper (16:9)
  const videoRef = useRef(null);
  const overlayRef = useRef(null);          // visible overlay on top of <video>
  const facecamPreviewRef = useRef(null);   // small preview (optional)

  const [drawMode, setDrawMode] = useState(false);
  const [shapes, setShapes] = useState([]);
  const drawing = useRef(null);
  const tempShapeRef = useRef(null);        // live preview while dragging
  const freehandPoints = useRef([]);

  const [tool, setTool] = useState("line");
  const [color] = useState(DEFAULT_COLOR); // locked to red
  const [lineWidth, setLineWidth] = useState(3);

  // Analysis recording (composition via canvas capture)
  const [recording, setRecording] = useState(false);
  const recChunksRef = useRef([]);
  const recMediaRecorderRef = useRef(null);
  const micStreamRef = useRef(null);
  const facecamStreamRef = useRef(null);
  const compCanvasRef = useRef(null);
  const compRafRef = useRef(null);

  // Playback controls (custom)
  const [duration, setDuration] = useState(0);
  const [current, setCurrent] = useState(0);

  // ─────────────────────────────────────────────────────────────────────────────
  // Data load
  // ─────────────────────────────────────────────────────────────────────────────
  useEffect(() => {
    const fetchVideo = async () => {
      if (!videoId) {
        setLoading(false);
        return;
      }
      try {
        const snap = await getDoc(doc(db, "videos", videoId));
        if (snap.exists()) {
          const d = snap.data();
          setVideoUrl(d.url);
          setVideoName(d.name || "Untitled");
        }
      } catch (err) {
        console.error("❌ Failed to fetch video doc", err);
      } finally {
        setLoading(false);
      }
    };
    fetchVideo();
  }, [videoId]);

  // ─────────────────────────────────────────────────────────────────────────────
  // Render overlay (persistent shapes + temp preview)
  // ─────────────────────────────────────────────────────────────────────────────
  useEffect(() => {
    const c = overlayRef.current;
    const ctx = c?.getContext("2d");
    if (!c || !ctx) return;

    let rafId;
    const render = () => {
      const v = videoRef.current;

      // Match canvas internal pixel size to video natural size (best fidelity)
      const naturalW = v?.videoWidth || 1280;
      const naturalH = v?.videoHeight || 720;

      if (c.width !== naturalW) c.width = naturalW;
      if (c.height !== naturalH) c.height = naturalH;

      ctx.clearRect(0, 0, c.width, c.height);

      // draw saved shapes
      drawShapesArray(ctx, shapes);

      // draw in-progress preview
      const s = tempShapeRef.current;
      if (s) drawShapesArray(ctx, [s]);

      rafId = requestAnimationFrame(render);
    };

    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, [shapes]);

  function drawShapesArray(ctx, arr) {
    for (const s of arr) {
      if (!s) continue;
      ctx.strokeStyle = s.color || DEFAULT_COLOR;
      ctx.lineWidth = s.lineWidth || 2;

      if (s.type === "line") {
        const { x1, y1, x2, y2 } = s;
        if ([x1, y1, x2, y2].every((n) => typeof n === "number")) {
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
      }
      if (s.type === "rect") {
        const { x, y, w, h } = s;
        if ([x, y, w, h].every((n) => typeof n === "number")) {
          ctx.strokeRect(x, y, w, h);
        }
      }
      if (s.type === "circle") {
        const { cx, cy, r } = s;
        if ([cx, cy, r].every((n) => typeof n === "number")) {
          ctx.beginPath();
          ctx.arc(cx, cy, r, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
      if (s.type === "freehand") {
        const pts = Array.isArray(s.points) ? s.points : [];
        if (pts.length > 1) {
          ctx.beginPath();
          ctx.moveTo(pts[0].x, pts[0].y);
          for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
          ctx.stroke();
        }
      }
    }
  }

  // Mouse → canvas pixel coords (handles responsive CSS sizing)
  function getCanvasCoords(e) {
    const c = overlayRef.current;
    if (!c) return { x: 0, y: 0 };
    const rect = c.getBoundingClientRect();
    const scaleX = c.width / rect.width || 1;
    const scaleY = c.height / rect.height || 1;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    return { x, y };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Drawing handlers (only in draw mode)
  // ─────────────────────────────────────────────────────────────────────────────
  const startDraw = (e) => {
    if (!drawMode) return;

    const { x, y } = getCanvasCoords(e);

    if (tool === "eraser") {
      setShapes((prev) => {
        const hitIndex = findHitShapeIndex(prev, x, y);
        if (hitIndex >= 0) {
          const copy = [...prev];
          copy.splice(hitIndex, 1);
          return copy;
        }
        return prev;
      });
      tempShapeRef.current = null;
      return;
    }

    const seed = {
      type: tool,
      color,
      lineWidth,
      x1: x,
      y1: y,
      x2: x,
      y2: y,
      x: x,
      y: y,
      w: 0,
      h: 0,
      cx: x,
      cy: y,
      r: 0,
      points: tool === "freehand" ? [{ x, y }] : [],
    };
    drawing.current = seed;
    tempShapeRef.current = { ...seed };
  };

  const moveDraw = (e) => {
    if (!drawMode || !drawing.current) return;

    const { x, y } = getCanvasCoords(e);
    const s = { ...drawing.current };

    if (tool === "freehand") {
      s.points = [...(s.points || []), { x, y }];
    }
    if (tool === "line") {
      s.x2 = x;
      s.y2 = y;
    }
    if (tool === "rect") {
      s.x = s.x1;
      s.y = s.y1;
      s.w = x - s.x1;
      s.h = y - s.y1;
    }
    if (tool === "circle") {
      const dx = x - s.x1, dy = y - s.y1;
      s.cx = s.x1; s.cy = s.y1; s.r = Math.sqrt(dx*dx + dy*dy);
    }

    tempShapeRef.current = s;
    drawing.current = s;
  };

  const endDraw = (e) => {
    if (!drawMode || !drawing.current) return;

    const { x, y } = getCanvasCoords(e);
    let s = { ...drawing.current };

    if (tool === "line") s.x2 = x, s.y2 = y;
    if (tool === "rect") { s.x = s.x1; s.y = s.y1; s.w = x - s.x1; s.h = y - s.y1; }
    if (tool === "circle") { const dx = x - s.x1, dy = y - s.y1; s.cx = s.x1; s.cy = s.y1; s.r = Math.sqrt(dx*dx + dy*dy); }
    // freehand points already added during move

    setShapes((prev) => [...prev, s]);
    drawing.current = null;
    tempShapeRef.current = null; // clear preview
  };

  // Eraser hit-test helpers
  function findHitShapeIndex(arr, x, y) {
    for (let i = arr.length - 1; i >= 0; i--) {
      const s = arr[i];
      if (!s) continue;
      if (s.type === "line") {
        if (pointNearLine(x, y, s.x1, s.y1, s.x2, s.y2, Math.max(8, s.lineWidth + 4))) return i;
      }
      if (s.type === "rect") {
        const minX = Math.min(s.x, s.x + s.w);
        const maxX = Math.max(s.x, s.x + s.w);
        const minY = Math.min(s.y, s.y + s.h);
        const maxY = Math.max(s.y, s.y + s.h);
        if (x >= minX && x <= maxX && y >= minY && y <= maxY) return i;
      }
      if (s.type === "circle") {
        const dx = x - s.cx, dy = y - s.cy;
        if (Math.sqrt(dx*dx + dy*dy) <= s.r + Math.max(6, s.lineWidth)) return i;
      }
      if (s.type === "freehand") {
        const pts = s.points || [];
        for (let j = 1; j < pts.length; j++) {
          if (pointNearLine(x, y, pts[j-1].x, pts[j-1].y, pts[j].x, pts[j].y, Math.max(8, s.lineWidth + 4))) return i;
        }
      }
    }
    return -1;
  }
  function pointNearLine(px, py, x1, y1, x2, y2, tolerance) {
    const A = px - x1, B = py - y1, C = x2 - x1, D = y2 - y1;
    const dot = A * C + B * D;
    const lenSq = C * C + D * D || 1;
    let t = dot / lenSq;
    t = Math.max(0, Math.min(1, t));
    const lx = x1 + t * C, ly = y1 + t * D;
    const dx = px - lx, dy = py - ly;
    return dx * dx + dy * dy <= tolerance * tolerance;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Video metadata & time — SINGLE DEFINITIONS
  // ─────────────────────────────────────────────────────────────────────────────
  const onLoadedMetadata = () => {
    const v = videoRef.current;
    if (v) setDuration(v.duration || 0);
  };

  const onTimeUpdate = () => {
    const v = videoRef.current;
    if (v) setCurrent(v.currentTime || 0);
  };

  const playPause = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play(); else v.pause();
  };

  const onSeek = (e) => {
    const v = videoRef.current; if (!v) return;
    const t = Number(e.target.value); v.currentTime = t; setCurrent(t);
  };

  // ─────────────────────────────────────────────────────────────────────────────
  // Save annotations JSON
  // ─────────────────────────────────────────────────────────────────────────────
  const saveReview = async () => {
    const base = videoName.replace(/\.mp4$/i, "");
    const jsonRef = ref(storage, `reviews/${base}-review.json`);
    const clean = (Array.isArray(shapes) ? shapes : []).filter(Boolean);
    const blob = new Blob([JSON.stringify(clean)], { type: "application/json" });
    await uploadBytes(jsonRef, blob);
    await updateDoc(doc(db, "videos", videoId), {
      reviewed: true,
      reviewedAt: serverTimestamp(),
    });
    alert("✅ Review saved");
  };

  // ─────────────────────────────────────────────────────────────────────────────
  // Composition recorder (NO screen picker): record canvas(video+overlay+facecam) + mic
  // ─────────────────────────────────────────────────────────────────────────────
  const startAnalysis = async () => {
    try {
      // mic
      micStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      // facecam (optional preview)
      facecamStreamRef.current = await navigator.mediaDevices.getUserMedia({ video: true });
      if (facecamPreviewRef.current) facecamPreviewRef.current.srcObject = facecamStreamRef.current;

      const v = videoRef.current;
      if (!v) throw new Error("Video not ready");
      const naturalW = v.videoWidth || 1280;
      const naturalH = v.videoHeight || 720;

      // composition canvas
      let compCanvas = compCanvasRef.current;
      if (!compCanvas) {
        compCanvas = document.createElement("canvas");
        compCanvasRef.current = compCanvas;
      }
      compCanvas.width = naturalW;
      compCanvas.height = naturalH;
      const ctx = compCanvas.getContext("2d");

      // hidden <video> for facecam drawing
      const faceVid = document.createElement("video");
      faceVid.muted = true; faceVid.playsInline = true; faceVid.autoplay = true;
      faceVid.srcObject = facecamStreamRef.current;

      const drawFrame = () => {
        // background
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, naturalW, naturalH);

        // base video frame
        try { ctx.drawImage(v, 0, 0, naturalW, naturalH); } catch {}

        // draw persisted shapes + temp preview
        drawShapesArray(ctx, shapes);
        const s = tempShapeRef.current; if (s) drawShapesArray(ctx, [s]);

        // facecam PIP (top-right)
        try {
          ctx.save();
          const pipW = Math.floor(naturalW * 0.25);
          const pipH = Math.floor(naturalH * 0.25);
          ctx.strokeStyle = "rgba(255,255,255,0.8)";
          ctx.lineWidth = 2;
          ctx.drawImage(faceVid, naturalW - pipW - 10, 10, pipW, pipH);
          ctx.strokeRect(naturalW - pipW - 10, 10, pipW, pipH);
          ctx.restore();
        } catch {}

        compRafRef.current = requestAnimationFrame(drawFrame);
      };
      drawFrame();

      // capture canvas stream
      const canvasStream = compCanvas.captureStream(30); // 30fps
      // combine with mic audio
      const combined = new MediaStream();
      canvasStream.getVideoTracks().forEach((t) => combined.addTrack(t));
      micStreamRef.current.getAudioTracks().forEach((t) => combined.addTrack(t));

      // record
      const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")
        ? "video/webm;codecs=vp9,opus"
        : MediaRecorder.isTypeSupported("video/webm;codecs=vp8,opus")
        ? "video/webm;codecs=vp8,opus"
        : "video/webm";
      const mr = new MediaRecorder(combined, { mimeType: mime, videoBitsPerSecond: 5_000_000 });
      recChunksRef.current = [];
      mr.ondataavailable = (e) => e.data.size > 0 && recChunksRef.current.push(e.data);
      mr.onstop = async () => {
        try {
          cancelAnimationFrame(compRafRef.current);
          const base = videoName.replace(/\.mp4$/i, "");
          const blob = new Blob(recChunksRef.current, { type: mime });
          const buf = await blob.arrayBuffer();
          const analysisRef = ref(storage, `reviews/${base}-analysis.webm`);
          await uploadBytes(analysisRef, new Uint8Array(buf), { contentType: "video/webm" });
          await updateDoc(doc(db, "videos", videoId), {
            reviewed: true,
            reviewedAt: serverTimestamp(),
          });
          alert("✅ Analysis uploaded");
        } catch (err) {
          console.error("Upload analysis failed", err);
          alert("Upload analysis failed");
        } finally {
          try {
            micStreamRef.current?.getTracks().forEach((t) => t.stop());
            facecamStreamRef.current?.getTracks().forEach((t) => t.stop());
            if (facecamPreviewRef.current) facecamPreviewRef.current.srcObject = null;
          } catch {}
        }
      };
      recMediaRecorderRef.current = mr;
      mr.start();
      setRecording(true);
    } catch (err) {
      console.error("startAnalysis error:", err);
      alert("Mic/Camera permission denied or not available");
    }
  };

  const stopAnalysis = () => {
    const mr = recMediaRecorderRef.current;
    if (mr && mr.state !== "inactive") {
      mr.stop();
    }
    setRecording(false);
  };

  // ─────────────────────────────────────────────────────────────────────────────
  // UI
  // ─────────────────────────────────────────────────────────────────────────────
  if (!videoId) return <p style={{ padding: 20 }}>⚠️ No video selected.</p>;
  if (loading) return <p style={{ padding: 20 }}>Loading video…</p>;
  if (!videoUrl) return <p style={{ padding: 20 }}>Video not found.</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Coach Editor</h2>
      <p><em>{videoName}</em></p>

      {/* Controls Row */}
      <div style={{ marginBottom: 10, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <button onClick={() => setDrawMode((d) => !d)}>
          {drawMode ? "✅ Draw Mode (ON)" : "✏️ Draw Mode (OFF)"}
        </button>

        <span>Tool:</span>
        {TOOLS.map((t) => (
          <button
            key={t}
            onClick={() => setTool(t)}
            disabled={!drawMode}
            style={{ fontWeight: tool === t ? "bold" : "normal" }}
          >
            {t}
          </button>
        ))}

        <label>
          Width:
          <input
            type="number"
            min={1}
            max={12}
            value={lineWidth}
            onChange={(e) => setLineWidth(Number(e.target.value))}
            disabled={!drawMode}
            style={{ width: 60, marginLeft: 6 }}
          />
        </label>

        <div style={{ display: "flex", gap: 8, marginLeft: 8 }}>
          <button
            disabled={!drawMode}
            onClick={() => setShapes((prev) => prev.slice(0, -1))}
            title="Undo last"
          >
            Undo
          </button>
          <button
            disabled={!drawMode}
            onClick={() => setShapes([])}
            title="Clear all"
          >
            Clear
          </button>
        </div>

        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          {!recording ? (
            <button onClick={startAnalysis}>Start Analysis</button>
          ) : (
            <button onClick={stopAnalysis}>Stop Analysis</button>
          )}
          <button onClick={saveReview}>Save Annotations JSON</button>
          <button onClick={() => navigate("/dashboard")}>Back</button>
        </div>
      </div>

      {/* Responsive Stage: 16:9 that fills width; video+canvas fill it */}
      <div
        ref={stageRef}
        style={{
          position: "relative",
          width: "100%",
          maxWidth: 1000,
          aspectRatio: "16 / 9",
          background: "#000",
          borderRadius: 8,
          overflow: "hidden",
        }}
      >
        <video
          ref={videoRef}
          src={videoUrl}
          controls={false}                 // single scrubber below
          onLoadedMetadata={onLoadedMetadata}
          onTimeUpdate={onTimeUpdate}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "contain",
          }}
        />
        <canvas
          ref={overlayRef}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",      // CSS size matches stage
            height: "100%",
            cursor: drawMode ? "crosshair" : "default",
            pointerEvents: drawMode ? "auto" : "none",
          }}
          onMouseDown={startDraw}
          onMouseMove={moveDraw}
          onMouseUp={endDraw}
        />
        {/* Tiny facecam preview (only while recording) */}
        <video
          ref={facecamPreviewRef}
          autoPlay
          muted
          playsInline
          style={{
            position: "absolute",
            right: 10,
            top: 10,
            width: "18%",
            aspectRatio: "16/9",
            background: "#111",
            borderRadius: 8,
            border: "2px solid rgba(255,255,255,0.6)",
            objectFit: "cover",
            display: recording ? "block" : "none",
          }}
        />
      </div>

      {/* Our single scrubber below */}
      <div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 8 }}>
        <button onClick={playPause}>Play/Pause</button>
        <input
          type="range"
          min={0}
          max={Math.max(duration, 0)}
          step="0.01"
          value={current}
          onChange={onSeek}
          style={{ width: 420 }}
        />
        <span style={{ fontVariantNumeric: "tabular-nums" }}>
          {current.toFixed(1)} / {Number.isFinite(duration) ? duration.toFixed(1) : "0.0"}s
        </span>
      </div>
    </div>
  );
}
